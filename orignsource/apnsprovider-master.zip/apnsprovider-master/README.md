# Easy APNs Provider

A simple App to send Apple Push Notification to your devices for testing.
You can download the builded version of this via Mac App Store.
The only lib which is called "nopqziplib" depeneded by this app can be cloned via https://github.com/fhydralisk/nopqziplib.git
